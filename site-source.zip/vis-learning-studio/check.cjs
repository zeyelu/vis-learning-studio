const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const nodes=new Map;function get(k){if(!nodes.has(k))nodes.set(k,{innerHTML:'',textContent:'',value:'',classList:{add(){},remove(){},toggle(){}},focus(){},setSelectionRange(){}});return nodes.get(k)}
const ctx={window:{addEventListener(){},scrollTo(){}},document:{querySelector:get,querySelectorAll:()=>[],addEventListener(){},body:{classList:{toggle(){},contains(){return false}}}},location:{hash:''},localStorage:{getItem(){return null},setItem(){}},setTimeout(){},console};
vm.createContext(ctx);vm.runInContext(fs.readFileSync(__dirname+'/content.js','utf8'),ctx);vm.runInContext(fs.readFileSync(__dirname+'/app.js','utf8'),ctx);
const run=s=>vm.runInContext(s,ctx);assert.equal(run('all.length'),27);
for(const c of ctx.window.COURSE)for(const l of c.lessons){assert(l.html.length>100,l.id+' missing content');assert(!/<script|<iframe|<video/i.test(l.html));ctx.location.hash='#'+l.id;for(const m of ['guide','code','demo','quiz']){run(`mode='${m}';render()`);assert(get('#main').innerHTML.length>500);assert(!get('#main').innerHTML.includes('undefined'),'bad content '+l.id)}}
for(let n=1;n<=5;n++){ctx.location.hash='#lab-'+n;get('#encoding').value='bar';get('#order').value='original';get('#palette').value='seq';get('#count').value=5;get('#baseline').value=0;get('#window').value=3;run('render()');assert(get('#lab-chart').innerHTML.includes('<svg'));assert(!/NaN|undefined/.test(get('#lab-chart').innerHTML))}
run('lab=2');get('#count').value=8;run('draw()');assert(get('#lab-output').textContent.includes('enter 3'));get('#count').value=1;run('draw()');assert(get('#lab-output').textContent.includes('exit 4'));
run('lab=4');get('#baseline').value=75;run('draw()');assert(get('#lab-output').textContent.includes('5.00'));
run('lab=5');get('#window').value=3;run('draw()');assert(get('#lab-output').textContent.includes('85.7'));
run("search='不存在的知识点xyz';sidebar()");assert(get('#sidebar').innerHTML.includes('无匹配内容'));
run("saved.notes['ch-1-1']='<script>alert(1)</script>';location.hash='#review';render()");assert(!get('#main').innerHTML.includes('<script>'));assert(get('#main').innerHTML.includes('&lt;script&gt;'));
console.log('PASS: 27 source lessons, 108 reader states, 5 SVG labs, join bounds, baseline ratio, rolling mean, search and note escaping.');
